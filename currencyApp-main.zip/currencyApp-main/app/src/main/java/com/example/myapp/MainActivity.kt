package com.example.myapp

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val spinnerFrom: Spinner = findViewById(R.id.spinnerFrom)
        val spinnerTo: Spinner = findViewById(R.id.spinnerTo)
        val editTextAmount: EditText = findViewById(R.id.editTextAmount)
        val textViewResult: TextView = findViewById(R.id.textViewResult)
        val buttonConvert: Button = findViewById(R.id.buttonConvert)

        val currencies = arrayOf("USD", "EUR", "VND", "JPY", "WON")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, currencies)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerFrom.adapter = adapter
        spinnerTo.adapter = adapter

        val exchangeRates = mapOf(
            "USD" to 1.0,
            "EUR" to 0.92,
            "VND" to 25575.00,
            "JPY" to 150.06,
            "WON" to 1467.60
        )

        buttonConvert.setOnClickListener {
            val amountStr = editTextAmount.text.toString()
            if (amountStr.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập số tiền", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val amount = amountStr.toDouble()
            val fromCurrency = spinnerFrom.selectedItem.toString()
            val toCurrency = spinnerTo.selectedItem.toString()

            val amountInUSD = amount / exchangeRates[fromCurrency]!!
            val result = amountInUSD * exchangeRates[toCurrency]!!
            textViewResult.text = String.format("%.2f %s", result, toCurrency)
        }
    }
}